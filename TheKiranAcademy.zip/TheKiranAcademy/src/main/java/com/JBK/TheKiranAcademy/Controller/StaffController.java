package com.JBK.TheKiranAcademy.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.RestController;
import com.JBK.TheKiranAcademy.Entity.Staff;
import com.JBK.TheKiranAcademy.Entity.User;
import com.JBK.TheKiranAcademy.Service.StaffService;

@Controller
public class StaffController {
	@Autowired
	StaffService staff;
	
	@GetMapping("/allrecords")//1.done
	public ModelAndView getStaffRecord() {
		ModelAndView view = new ModelAndView();
		view.setViewName("home");
		List<Staff> slist = staff.getStaffRecord();
		System.out.println("List iss...:"+slist);
		view.addObject("staffrecords",slist);
		return view;
	}
	
	@RequestMapping("/checkauthentication")
	public ModelAndView checkLogin(User user) {
		String uname = user.getUsername();
		String pass = user.getPassword();
		System.out.println(uname+" "+ pass);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("login");
		return mv;
	}
	
	@PostMapping("/insertrecords")//2.done
	public String insertStaffRecord(@RequestBody List<Staff> slist) {
		String msg = staff.insertStaffRecord(slist);
		return msg;
	}
	
	@PostMapping("/insertsinglerecord")//3.done
	public String insertSingleRecord(@RequestBody Staff s) {
		String msg = staff.insertSingleRecord(s);
		return msg;
	}
	
	@GetMapping("/getrecordbyid/{staffid}")//4.done
	public Staff getStaffByID(@PathVariable int staffid) {
		Staff s = staff.getStaffByID(staffid);
		return s;
	}
	
	@GetMapping("/getsalarygt20k")//5.done
	public List<Staff> getSalaryGT20k(){
		List<Staff> slist = staff.getSalaryGT20k();
		System.out.println("In controller...."+slist);
		return slist;
	}
	
	@GetMapping("/getmaximumsalary")//6.done
	public Staff getMaxSalary() {
		Staff s = staff.getMaxSalary();
		return s;
	}
	
	@GetMapping("/getminimumsalary")//7.done
	public Staff getMinSalary() {
		Staff s = staff.getMinSalary();
		return s;
	}
	
	@PutMapping("/updatesalary")//8.done
	public String updateSalary(@RequestBody Staff s) {
		String msg= staff.updateSalary(s.getStaffid(),s.getSalary());
		return msg;
	}
	
	@GetMapping("/getstaffexperience")//9.done
	public List<Staff> getStaffExperience(){
		List<Staff> slist = staff.getStaffExperience();
		return slist;
	}
	
	@GetMapping("/gettrainerprofile")//10.done
	public List<Staff> getTrainerProfile(){
		List<Staff> slist = staff.getTrainerProfile();
		return slist;
	}
	
	@GetMapping("/getnotrainerprofile")//11.done
	public List<Staff> getNoTrainerProfile(){
		List<Staff> slist = staff.getNoTrainerProfile();
		return slist;
	}
	
	@GetMapping("/getminexperience")//12.done
	public String getMinExperience() {
		String sname= staff.getMinExperience();
		return sname;
	}
}
