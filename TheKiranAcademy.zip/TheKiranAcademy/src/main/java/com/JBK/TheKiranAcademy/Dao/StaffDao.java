package com.JBK.TheKiranAcademy.Dao;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.loader.criteria.CriteriaQueryTranslator;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.JBK.TheKiranAcademy.Entity.Staff;

@Repository
public class StaffDao {

	@Autowired
	SessionFactory sf;
	public List<Staff> getStaffRecord() {
		Session session = sf.openSession();
		Criteria criteria= session.createCriteria(Staff.class);
		List<Staff> slist = criteria.list();
		return slist;
	}
	
	public String insertStaffRecord(List<Staff> slist) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		for (Staff staff : slist) {
			session.save(staff);
		}
		tr.commit();
		return "Staffs inserted Succesfully...!!!";
		
	}

	public String insertSingleRecord(Staff s) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(s);
		tr.commit();
		return "Staff inserted Successfully...!!!";
	}

	public Staff getStaffByID(int staffid) {
		Session session = sf.openSession();
		Staff s = session.get(Staff.class,staffid);
		return s;
	}
	
	public List<Staff> getSalaryGT20k(){
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		Criteria clist =  criteria.add(Restrictions.gt("salary",20000.0));
		List<Staff> slist = clist.list();
		System.out.println(slist);
		return slist;
	}
	
	public Staff getMaxSalary() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		List<Staff> slist= criteria.list();
		double max= slist.get(0).getSalary();
		Staff maxlist = slist.get(0);
		for (Staff staff : slist) {
			if(max < staff.getSalary()) {
				max= staff.getSalary();
				maxlist = staff;
			}
		}
//		for (Staff staff : slist) {
//			if(max==staff.getSalary())
//				maxlist.add(staff);
//		}
		return maxlist;
	}
	
	public Staff getMinSalary() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		List<Staff> slist= criteria.list();
		double min= slist.get(0).getSalary();
		Staff minlist = slist.get(0);
		for (Staff staff : slist) {
			if(min > staff.getSalary()) {
				min= staff.getSalary();
				minlist = staff;
			}
		}
		return minlist;
	}

	public String updateSalary(int staffid, double salary) {
		Session session = sf.openSession();
		Staff s = session.find(Staff.class,staffid);
		Transaction tr = session.beginTransaction();
		s.setSalary(salary);
		session.update(s);
		tr.commit();
		return "Salary updated Successfully...!!!";
	}

	public List<Staff> getStaffExperience() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		Criteria clist = criteria.add(Restrictions.between("experience",10,20));
		List<Staff> slist = clist.list();
		return slist;
	}
	
	public List<Staff> getTrainerProfile(){
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		Criteria clist = criteria.add(Restrictions.eq("profile","Trainer"));
		List<Staff> slist = clist.list();
		return slist;
	}

	public List<Staff> getNoTrainerProfile() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		Criteria clist = criteria.add(Restrictions.ne("profile","Trainer"));
		List<Staff> slist = clist.list();
		return slist;
	}
	
	public String getMinExperience() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		List<Staff> slist = criteria.list();
		Staff s= slist.get(0);
		int min = slist.get(0).getExperience();
		for (Staff staff : slist) {
			if(min>staff.getExperience()) {
				min= staff.getExperience();
				s= staff;
			}
		}
		return s.getName();
	}

}
