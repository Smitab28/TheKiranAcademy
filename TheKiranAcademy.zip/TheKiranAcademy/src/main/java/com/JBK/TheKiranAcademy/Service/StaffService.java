package com.JBK.TheKiranAcademy.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JBK.TheKiranAcademy.Dao.StaffDao;
import com.JBK.TheKiranAcademy.Entity.Staff;

@Service
public class StaffService {
    
	@Autowired
	StaffDao staff;
	public List<Staff> getStaffRecord() {
		List<Staff> slist  = staff.getStaffRecord();
		return slist;
	}
	
	public String insertStaffRecord(List<Staff> slist) {
		String msg = staff.insertStaffRecord(slist);
		return msg;
	}

	public String insertSingleRecord(Staff s) {
		String msg= staff.insertSingleRecord(s);
		return msg;
	}

	public Staff getStaffByID(int staffid) {
		Staff s = staff.getStaffByID(staffid);
		return s;
	}

	public List<Staff> getSalaryGT20k(){
		List<Staff> slist =  staff.getSalaryGT20k();
	     return slist;
	}
	
	public Staff getMaxSalary() {
		Staff s = staff.getMaxSalary();
		return s;
	}
	
	public Staff getMinSalary() {
		Staff s = staff.getMinSalary();
		return s;
	}

	public String updateSalary(int staffid, double salary) {
		String msg = staff.updateSalary(staffid,salary);
		return msg;
	}

	public List<Staff> getStaffExperience() {
		List<Staff> slist = staff.getStaffExperience();
		return slist;
	}
	
	public List<Staff> getTrainerProfile(){
		List<Staff> slist = staff.getTrainerProfile();
		return slist;
	}

	public List<Staff> getNoTrainerProfile() {
		List<Staff> slist= staff.getNoTrainerProfile();
		return slist;
	}
	public String getMinExperience() {
		String sname= staff.getMinExperience();
		return sname;
	}
}
