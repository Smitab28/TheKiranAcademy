package com.JBK.TheKiranAcademy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheKiranAcademyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheKiranAcademyApplication.class, args);
	}

}
