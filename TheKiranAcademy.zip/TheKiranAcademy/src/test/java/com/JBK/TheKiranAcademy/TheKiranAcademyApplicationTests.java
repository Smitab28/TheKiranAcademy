package com.JBK.TheKiranAcademy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheKiranAcademyApplicationTests {

	@Test
	void contextLoads() {
	}

}
